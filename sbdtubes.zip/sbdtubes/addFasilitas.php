<?php
  include('function.php');

  $listFasilitas = readfasilitas();
  $listJadwal = readjadwal();
  // Jika tombol tambah fasilitas ditekan
if (isset($_POST['tambah_fasilitas'])) {
    $isAddSucceed = addFasilitas($_POST, $_FILES);
    if ($isAddSucceed > 0) {
        // jika penambahan sukses, tampilkan alert
        echo "
        <script>
            alert('Data Berhasil Ditambahkan');
            document.location.href = 'adb.php'; 
        </script>";
        //kemana si action berjalan setelah data berhasil dijalankan
    } else {
        echo "
        <script>
            alert('Gagal menambahkan Data !');
            document.location.href = 'adb.php';
        </script>
        ";
    }
}

// Jika tombol edit fasilitas ditekan
// if (isset($_POST['edit_fasilitas'])) {
//     $id = $_POST['id'];
//     $nama = $_POST['nama'];
//     $deskripsi = $_POST['deskripsi'];
//     $harga = $_POST['harga'];
//     $stok = $_POST['stok'];
//     $gambar = $_POST['gambar'];

//     updateFasilitas($id, $nama, $deskripsi, $harga, $stok, $gambar);
// }

// Jika tombol hapus fasilitas ditekan
// if (isset($_POST['hapus_fasilitas'])) {
//     $id = $_POST['id'];

//     deleteFasilitas($id);
// }

// $listFasilitas = readFasilitas();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Futsal</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Sailor
  * Template URL: https://bootstrapmade.com/sailor-free-bootstrap-theme/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

    <!-- Tampilkan Form Tambah Fasilitas -->
    <form method="post" action="" enctype="multipart/form-data">
        <input type="hidden" name="Id_fasilitas">
        <input type="text" name="nama" placeholder="Nama Fasilitas" required>
        <input type="text" name="deskripsi" placeholder="Deskripsi Fasilitas" required>
        <input type="text" name="harga" placeholder="Harga" required>
        <input type="text" name="stok" placeholder="Stok" required>
        <input type="file" name="gambar" placeholder="gambar" required>
        <button type="submit" name="tambah_fasilitas">Tambah Fasilitas</button>
    </form>
    
        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>
</body>
