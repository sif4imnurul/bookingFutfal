<?php
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "bookingfutsal";

    $conn = mysqli_connect($host, $username, $password, $database); //untuk menyambungkan file php dengan database
    
   if(!$conn){
       die ("Koneksi dengan database gagal: ".mysqli_connect_error());
   }else{
       echo 'sukses';
   }
    
?>
