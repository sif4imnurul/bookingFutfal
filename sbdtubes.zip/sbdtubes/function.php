<?php
// Deklarasikan variabel global $conn di luar fungsi
include('config.php');
global $conn;

// function getLastInsertedId($tableName, $idColumnName) {
//     global $conn; // Pastikan koneksi database sudah tersedia

//     // Query untuk mendapatkan ID terakhir yang di-insert
//     $query = "SELECT MAX($idColumnName) AS last_id FROM $tableName";

//     $result = mysqli_query($conn, $query);

//     if (!$result) {
//         die("Query failed: " . mysqli_error($conn));
//     }

//     // Ambil hasil query
//     $row = mysqli_fetch_assoc($result);

//     // Ambil ID terakhir
//     $lastId = $row['last_id'];

//     // Bebaskan memory dari hasil query
//     mysqli_free_result($result);

//     return $lastId; // Kembalikan ID terakhir
// }
// Fungsi untuk membaca data dari tabel fasilitas
function readQuery($table, $id, $find){ //untuk mengambil satu data
    global $conn;
    $query = "SELECT * FROM ".$table." WHERE ".$id."=".$find; //tablenya itu sesuai dengan yang kita inginkan //id itu kolom pk //
    $result = mysqli_query($conn, $query);
    $result = mysqli_fetch_assoc($result); //mengambil 1 data paling atas dari yang sudah kita buat


    return $result;
};
function readjadwal() {
    global $conn;
    // Query untuk membaca data dari tabel jadwal;
    $qry = "SELECT * FROM jadwal";
    $result = mysqli_query($conn, $qry); //jalankan query diatas, ditampung dalam variabel result untuk mereturn array 
    //conn di kiri query di kanan koneksi di kiri, kueri di kanan (sesuai nama yang kita buat conn dan querynya)

    return $result;

}

function readmembership() {
    global $conn;
    // Query untuk membaca data dari tabel jadwal;
    //$qry = "SELECT * FROM membership";
    $qry = "SELECT pengguna.Nama, membership.* FROM membership RIGHT JOIN pengguna ON membership.Id_pengguna = pengguna.Id_pengguna";
    $result = mysqli_query($conn, $qry); //jalankan query diatas, ditampung dalam variabel result untuk mereturn array 
    //conn di kiri query di kanan koneksi di kiri, kueri di kanan (sesuai nama yang kita buat conn dan querynya)

    return $result;

}
function readfasilitas() {
    global $conn;
    // Query untuk membaca data dari tabel fasilitas;
    $qry = "SELECT * FROM fasilitas";
    $result = mysqli_query($conn, $qry); //jalankan query diatas, ditampung dalam variabel result untuk mereturn array 
    //conn di kiri query di kanan koneksi di kiri, kueri di kanan (sesuai nama yang kita buat conn dan querynya)

    return $result;

}

function readBooking() {
    global $conn;
    // Query untuk membaca data dari tabel fasilitas;
    $qry = "SELECT 
        booking.*, fasilitas.*, pengguna.*, ekstra_fasilitas.*
        FROM 
            booking
        LEFT JOIN 
            fasilitas ON booking.id_fasilitas = fasilitas.Id_fasilitas
        LEFT JOIN 
            pengguna ON booking.id_pengguna = pengguna.Id_pengguna
        LEFT JOIN 
            ekstra_fasilitas ON booking.id_ekstra_fasilitas = ekstra_fasilitas.Id_ekstra_fasilitas;
        ";
    $result = mysqli_query($conn, $qry); //jalankan query diatas, ditampung dalam variabel result untuk mereturn array 
    //conn di kiri query di kanan koneksi di kiri, kueri di kanan (sesuai nama yang kita buat conn dan querynya)

    return $result;

}

function addBooking($data, $file){
        global $conn;
    
        $id_fasilitas = $data['Id_fasilitas'];
        $id_pengguna = $data['Id_pengguna'];
        $id_ekstra_fasilitas = $data['Id_ekstra_fasilitas'];
        $tanggal_booking = $data['Tanggal_booking'];
        $waktu_mulai = $data['Waktu_mulai'];
        $waktu_selesai = $data['Waktu_selesai'];
        $uang_muka = $data['Uang_muka'];
        $status = $data['Status'];
        
        $query = "INSERT INTO booking (Id_fasilitas,Id_pengguna, Id_ekstra_fasilitas, Tanggal_booking, Waktu_mulai, Waktu_selesai, Uang_muka, Status) VALUES ('$id_fasilitas','$id_pengguna', '$id_ekstra_fasilitas', '$tanggal_booking', '$waktu_mulai', '$waktu_selesai', '$uang_muka', '$status')";
        $result = mysqli_query($conn, $query);
        
        $isSucceed = mysqli_affected_rows($conn); //jika berhasil maka 
    
        return $isSucceed;
}

// Create function to add new facility
function addFasilitas($data, $file) {
    // Include your database connection
    // Example: include('connection.php');

    // Assuming you have a database connection object named $conn
    global $conn;

    // $nama = mysqli_real_escape_string($conn, $nama);
    // $deskripsi = mysqli_real_escape_string($conn, $deskripsi);
    // $harga = mysqli_real_escape_string($conn, $harga);
    // $stok = mysqli_real_escape_string($conn, $stok);
    // $gambar = mysqli_real_escape_string($conn, $gambar);

    // $query = "INSERT INTO fasilitas (Nama, Deskripsi, Harga, Stok, gambar) VALUES ('$nama', '$deskripsi', '$harga', '$stok', '$gambar')";
    // $result = mysqli_query($conn, $query);

    // // Check if query was successful
    // if (!$result) {
    //     die("Query failed: " . mysqli_error($conn));
    // }

    // // Close connection
    // mysqli_close($conn);


    // $id = getLastInsertedId('fasilitas', 'Id_fasilitas'); 
        // Handle the case where 'gambar' key is not present in $_FILES
        if(isset($file['gambar'])) {
            $namaFoto = $file['gambar']['name'];
            $tempNamaFoto = $file['gambar']['tmp_name'];
            $direktori = 'assets/img/fasilitas/'.$namaFoto;
            $isMoved = move_uploaded_file($tempNamaFoto, $direktori); //nama foto di server phpnya
            if(!$isMoved){
                $namaFoto = 'default.jpg';
            }
        } else {
            $namaFoto = 'default.jpg';
        }
    
        // Retrieve other data from $data array
        $nama = $data['nama']; 
        $deskripsi = $data['deskripsi'];
        $harga = $data['harga'];
        $stok = $data['stok'];
        // $gambar = $data['gambar']; // This line is not needed since we're using $namaFoto for the image filename.
    
        // Use mysqli_real_escape_string to prevent SQL injection
        $nama = mysqli_real_escape_string($conn, $nama);
        $deskripsi = mysqli_real_escape_string($conn, $deskripsi);
        $harga = mysqli_real_escape_string($conn, $harga);
        $stok = mysqli_real_escape_string($conn, $stok);
        $gambar = mysqli_real_escape_string($conn, $namaFoto);
    
        // Construct and execute the query
        $query = "INSERT INTO fasilitas (Id_fasilitas, Nama, Deskripsi, Harga, Stok, gambar) 
                  VALUES ('', '$nama', '$deskripsi', '$harga', '$stok', '$gambar')";
    
        $result = mysqli_query($conn, $query);
    
        // Check if the query was successful
        if (!$result) {
            die("Query failed: " . mysqli_error($conn));
        }
    
        // Return the number of affected rows
        $isSucceed = mysqli_affected_rows($conn);
    
        return $isSucceed;
    
}    

// Create function to update facility
function updateFasilitas($data, $file){
    // Include your database connection
    // Example: include('connection.php');

    // Assuming you have a database connection object named $conn
    global $conn;

    $id = $data['id'];
    $nama = $data['nama'];
    $deskripsi = $data['deskripsi'];
    $harga = $data['harga'];
    $stok = $data['stok'];
    $namaFoto = $file['gambar']['name'];

    if($namaFoto != ""){
        $tempNamaFoto = $file['gambar']['tmp_name'];
        $direktori = 'assets/img/fasilitas/'.$namaFoto;
        move_uploaded_file($tempNamaFoto, $direktori);
        $query = "UPDATE fasilitas SET Nama = '$nama', Deskripsi = '$deskripsi', Harga = '$harga', Stok = '$stok', gambar = '$namaFoto' WHERE Id_fasilitas = $id";
        $result = mysqli_query($conn, $query);
    } else{
        $query = "UPDATE fasilitas SET Nama = '$nama', Deskripsi = '$deskripsi', Harga = '$harga', Stok = '$stok' WHERE Id_fasilitas = $id";
        $result = mysqli_query($conn, $query);
    }
    $isSucceed = mysqli_affected_rows($conn);
    return $isSucceed;
}

// Create function to delete facility
function deleteFasilitas($id) {
    // Include your database connection
    // Example: include('connection.php');

    // Assuming you have a database connection object named $conn
    global $conn;

    $id = mysqli_real_escape_string($conn, $id);

    $query = "DELETE FROM fasilitas WHERE Id_fasilitas = $id";
    $result = mysqli_query($conn, $query);

    // Check if query was successful
    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    // Close connection
    mysqli_close($conn);
}



function updateBooking($data, $file){
    global $conn;

    $id_booking = $data['Id_booking']; // perlu ditambahkan untuk menentukan booking mana yang akan diperbarui
    $id_fasilitas = $data['Id_fasilitas'];
    $id_pengguna = $data['Id_pengguna'];
    $id_ekstra_fasilitas = $data['Id_ekstra_fasilitas'];
    $tanggal_booking = $data['Tanggal_booking'];
    $waktu_mulai = $data['Waktu_mulai'];
    $waktu_selesai = $data['Waktu_selesai'];
    $uang_muka = $data['Uang_muka'];
    $status = $data['Status'];

    // Query untuk melakukan pembaruan pada tabel booking
    $query = "UPDATE booking SET 
                Id_fasilitas = '$id_fasilitas', 
                Id_pengguna = '$id_pengguna', 
                Id_ekstra_fasilitas = '$id_ekstra_fasilitas', 
                Tanggal_booking = '$tanggal_booking', 
                Waktu_mulai = '$waktu_mulai', 
                Waktu_selesai = '$waktu_selesai', 
                Uang_muka = '$uang_muka', 
                Status = '$status' 
              WHERE Id_booking = '$id_booking'";
    $result = mysqli_query($conn, $query); // Execute query

    $isSucceed = mysqli_affected_rows($conn); // Jika berhasil maka

    return $isSucceed;
}

function deleteBooking($id_booking) {
    global $conn;
    
    // Prepared statement untuk mencegah SQL injection
    $query = "DELETE FROM booking WHERE id_booking = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $id_booking);
    
    // Eksekusi statement
    mysqli_stmt_execute($stmt);
    
    // Mengembalikan jumlah baris yang terpengaruh
    return mysqli_stmt_affected_rows($stmt);
}
?>