<?php include('function.php'); 
      $fasilitasdata= readfasilitas();
      $membershipdata = readmembership();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Futsal</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Sailor
  * Template URL: https://bootstrapmade.com/sailor-free-bootstrap-theme/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.php">MB FUTSAL</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
        <li><a href="index.php" class="active">Home</a></li>
          <li><a href="jadwal.php">Jadwal</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li><a href="location.php">Location</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="#" class="getstarted">Login</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url(Sailor/assets/img/bola.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Welcome to <span>MB-Futsal</span></h2>
              <p class="animate__animated animate__fadeInUp">Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil ut aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse doloremque accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Booking Now</a>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item" style="background-image:  url(Sailor/assets/img/lapangan1.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Lorem Ipsum Dolor</h2>
              <p class="animate__animated animate__fadeInUp">Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil ut aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse doloremque accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Booking Now</a>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item" style="background-image:  url(Sailor/assets/img/orangbola.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Sequi ea ut et est quaerat</h2>
              <p class="animate__animated animate__fadeInUp">Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil ut aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse doloremque accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Booking Now</a>
            </div>
          </div>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>

    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row content">
          <div class="col-lg-6">
            <h2>Mb Futsal</h2>
            <h3>Fasilitas terbaik untuk bermain futsal</h3>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
            Kami menyediakan lapangan futsal dengan fasilitas modern dan nyaman untuk pengalaman bermain futsal yang menyenangkan. Pesan sekarang dan rasakan serunya bermain futsal bersama teman-teman Anda.
            </p>
            <ul>
              <li><i class="ri-check-double-line"></i> Penerangan yang memadai untuk permainan malam hari</li>
              <li><i class="ri-check-double-line"></i> Bola futsal dan rompi disediakan</li>
              <li><i class="ri-check-double-line"></i> Ekstra fasilitas yang memadai</li>
            </ul>
            <p class="fst-italic">
            Ayo bergabung dengan kami dan nikmati pengalaman bermain futsal terbaik di Mb-Futsal. Kami berkomitmen untuk memberikan layanan dan fasilitas terbaik untuk memastikan Anda mendapatkan waktu yang menyenangkan dan tak terlupakan.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Fasilitas Section ======= -->
    <section id="fasilitas" class="fasilitas section-bg">
    <div class="container">
      <h1 class="fw-bold text-center pb-5">FASILITAS</h1>
      <div class="row">

      <?php
      foreach ($fasilitasdata as $result) {
      ?>
          <div class="col-md-3 mb-4">
            <div class="card" style="width: 18rem;">
              <img src="assets/img/fasilitas/<?= $result['gambar']?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title"><?= $result['Nama'] . "<br>"; ?></h5>
                <p class="card-text"><?= $result['Deskripsi'] . "<br>"; ?></p>
                <div class="d-grid gap-1 d-md-flex justify-content-md-center">
                    <a href="#" class="btn btn-dark me-md-2">Book Now</a>
                    <a href="#" class="btn btn-dark">See Details</a>
                </div>
              </div>
            </div>
          </div>
      <?php } ?>
      </div>
    </div>
  </section>


    <!-- ======= Services Section ======= -->
    <section id="membership" class="membership section-bg">
      <div class="container">
        <h1 class="fw-bold text-center pb-5">MEMBERSHIP</h1>
        <div class="row justify-content-center">
          <?php foreach ($membershipdata as $result) { ?>
            <div class="col-md-3 mb-4 d-flex align-items-stretch">
              <div class="card" style="background-color: orange;">
                <div class="card-body">
                  <h5 class="card-title text-center"><?= $result['Nama'] . "<br>"; ?></h5>
                  <p class="card-text">Tanggal Mulai :<?= $result['Tanggal_mulai_keanggotaan'] . "<br>"; ?></p>
                  <p class="card-text">Tanggal Akhir :<?= $result['Tanggal_berakhir_keanggotaan'] . "<br>"; ?></p>
                  <p class="card-text">Status :<?= $result['Status'] . "<br>"; ?></p>
                  <p class="card-text">Hari :<?= $result['Hari'] . "<br>"; ?></p>
                  <p class="card-text">Waktu Awal :<?= $result['Waktu_awal'] . "<br>"; ?></p>
                  <p class="card-text">Waktu Akhir :<?= $result['Waktu_akhir'] . "<br>"; ?></p>
                </div>
              </div>
            </div>
          <?php } ?>
        </div>
      </div>
    </section>


    <!-- ======= Voucher Section ======= -->
    <section id="voucher" class="voucher section-bg">
      <div class="container">
        <h1  class="fw-bold text-center">VOUCHER</h1>
      </div>
    </section><!-- End Voucher Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="footer-info">
              <h3>Sailor</h3>
              <p>
                A108 Adam Street <br>
                NY 535022, USA<br><br>
                <strong>Phone:</strong> +1 5589 55488 55<br>
                <strong>Email:</strong> info@example.com<br>
              </p>
              <div class="social-links mt-3">
                <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
                <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Graphic Design</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Our Newsletter</h4>
            <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Sailor</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/sailor-free-bootstrap-theme/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->

 

</body>

</html>