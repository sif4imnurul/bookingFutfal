<?php
  include('function.php');
  $listFasilitas = readFasilitas();
  $listBooking = readBooking();
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Futsal</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Sailor
  * Template URL: https://bootstrapmade.com/sailor-free-bootstrap-theme/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- Dashboard Utama -->
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3">
        <div class="card text-white bg-primary mb-3">
          <div class="card-body">
            <h5 class="card-title">Total Pemesanan</h5>
            <p class="card-text" id="totalBookings">100</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-white bg-success mb-3">
          <div class="card-body">
            <h5 class="card-title">Pendapatan Bulanan</h5>
            <p class="card-text" id="monthlyRevenue">Rp 20.000.000</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-white bg-info mb-3">
          <div class="card-body">
            <h5 class="card-title">Pengguna Terdaftar</h5>
            <p class="card-text" id="totalUsers">150</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-white bg-warning mb-3">
          <div class="card-body">
            <h5 class="card-title">Persentase Okupansi</h5>
            <p class="card-text" id="occupancyRate">75%</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <nav id="sidebar>
    <div class="sidebar-header">
      <h3>Futsal</h3>
    </div>

    <ul class="list-unstyled components">
      <li class="active">
        <a href="#dashboard">Dashboard</a>
      </li>
      <li>
        <a href="#fasilitas">Fasilitas</a>
      </li>
      <li>
        <a href="#extra-fasilitas">Extra Fasilitas</a>
      </li>
      <li>
        <a href="#jadwal">Jadwal</a>
      </li>
      <li>
        <a href="#booking">Booking</a>
      </li>
      <li>
        <a href="#membership">Membership</a>
      </li>
      <li>
        <a href="#voucher">Voucher</a>
      </li>
      <li>
        <a href="#pembayaran">Pembayaran</a>
      </li>
    </ul>
  </nav>
  <!-- Manajemen Pemesanan -->
  <div class="container-fluid">
    <h2>Manajemen Pemesanan</h2>
    <button class="btn btn-primary mb-3">Tambah Pemesanan</button>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>Nama Pemesan</th>
          <th>Tanggal</th>
          <th>Waktu</th>
          <th>Fasilitas</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody id="bookingTableBody">
        <tr>
          <th scope="row">1</th>
          <td>John Doe</td>
          <td>2024-06-07</td>
          <td>18:00 - 19:00</td>
          <td>Fasilitas 1</td>
          <td>
            <button class="btn btn-warning">Edit</button>
            <button class="btn btn-danger">Hapus</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Manajemen Pengguna -->
  <div class="container-fluid">
    <h2>Manajemen Pengguna</h2>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>Nama</th>
          <th>Email</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody id="userTableBody">
        <tr>
          <th scope="row">1</th>
          <td>John Doe</td>
          <td>john@example.com</td>
          <td>
            <button class="btn btn-warning">Edit</button>
            <button class="btn btn-danger">Hapus</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Konfigurasi Fasilitas -->
  <div class="container-fluid">
    <h2>Konfigurasi Fasilitas</h2>
    <a class="btn btn-primary mb-3" href="addFasilitas.php">Tambah Fasilitas</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Gambar</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($listFasilitas as $fasilitas) : ?>
                <tr>
                    <td><?php echo $fasilitas['Nama']; ?></td>
                    <td><?php echo $fasilitas['Deskripsi']; ?></td>
                    <td><?php echo $fasilitas['Harga']; ?></td>
                    <td><?php echo $fasilitas['Stok']; ?></td>
                    <td><img src="assets/img/fasilitas/<?= $fasilitas['gambar']?>" alt="gambar fasilitas" width="100"></td>
                    <td>
                    <a href="editFasilitas.php?id=<?= $fasilitas['Id_fasilitas'] ?>" class="btn btn-warning">edit</a>

                    <a href="deleteFasilitas.php?id=<?= $fasilitas['Id_fasilitas'] ?>" class="btn btn-danger">delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
  </div>

  <!-- Konfigurasi Booking -->
  <div class="container-fluid">
    <h2>Konfigurasi Booking</h2>
    <a class="btn btn-primary mb-3" href="addBooking.php">Tambah Booking</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Fasilitas</th>
                <th>Ekstra Fasilitas</th>
                <th>Tanggal Booking</th>
                <th>Waktu Mulai</th>
                <th>Waktu Selesai</th>
                <th>Uang Muka</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($listBooking as $booking) : ?>
                <tr>
                    <td><?= $booking['Id_pengguna']; ?></td>
                    <td><?= $booking['Id_fasilitas']; ?></td>
                    <td><?= $booking['Nama']; ?></td>
                    <td><?= $booking['Tanggal_booking']; ?></td>
                    <td><?= $booking['Waktu_mulai']; ?></td>
                    <td><?= $booking['Waktu_selesai']; ?></td>
                    <td><?= $booking['Uang_muka']; ?></td>
                    <td><?= $booking['Status']; ?></td>
                    <td>
                    <a href="editBooking.php?id=<?= $booking['Id_booking'] ?>" class="btn btn-warning">edit</a>

                    <a href="deleteBooking.php?id=<?= $booking['Id_booking'] ?>" class="btn btn-danger">delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
  </div>

</body>

</html>
